import TrustBadges from '../TrustBadges';

export default function TrustBadgesExample() {
  return <TrustBadges />;
}
