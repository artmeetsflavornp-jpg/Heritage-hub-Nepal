import FarmModelCalculator from '../FarmModelCalculator';

export default function FarmModelCalculatorExample() {
  return <FarmModelCalculator />;
}
